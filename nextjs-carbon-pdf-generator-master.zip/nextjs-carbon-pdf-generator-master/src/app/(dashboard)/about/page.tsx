export default function Page() {
  return <h1>About page!</h1>
}
