import TestForm from '@/components/home/test-form'

export default function Page() {
  return <TestForm />
}
