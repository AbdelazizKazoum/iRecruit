import { useSession } from 'next-auth/react'

export interface AuthUser {
  user: {
    isAuthenticated: boolean
    id: string
    username: string
    fullname: string
    firstname: string
    lastname: string
    roles: string[]
  }
}

export const useAuthUser = (): AuthUser => {
  const { data, status } = useSession()

  const user = (data as any) || {}

  return {
    user: {
      isAuthenticated: status === 'authenticated',
      id: user.id,
      username: user.username,
      fullname: user.name,
      firstname: user.name,
      lastname: user.name,
      roles: user.roles
    }
  }
}
